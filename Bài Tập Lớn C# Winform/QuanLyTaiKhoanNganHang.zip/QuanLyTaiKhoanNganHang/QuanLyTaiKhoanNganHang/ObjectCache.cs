﻿namespace QuanLyTaiKhoanNganHang
{
    internal class ObjectCache
    {
    }
}